# Deterministic start: NPC yui at block (2,2) on the flat test area. All G5 NPCs are despawned first (identities are kept).
execute as @a[tag=g5_op,limit=1] run npcortex c1 despawn yui
execute as @a[tag=g5_op,limit=1] run npcortex c1 despawn g5n02
execute as @a[tag=g5_op,limit=1] run npcortex c1 despawn g5n03
execute as @a[tag=g5_op,limit=1] run npcortex c1 despawn g5n04
execute as @a[tag=g5_op,limit=1] run npcortex c1 despawn g5n05
execute as @a[tag=g5_op,limit=1] run npcortex c1 despawn g5n06
execute as @a[tag=g5_op,limit=1] run npcortex c1 despawn g5n07
execute as @a[tag=g5_op,limit=1] run npcortex c1 despawn g5n08
execute as @a[tag=g5_op,limit=1] run npcortex c1 despawn g5n09
execute as @a[tag=g5_op,limit=1] run npcortex c1 despawn g5n10
tp @a[tag=g5_op] 0.5 -60 0.5
execute as @a[tag=g5_op,limit=1] run npcortex c1 spawn yui
function npcortex_g5:lib/reset
