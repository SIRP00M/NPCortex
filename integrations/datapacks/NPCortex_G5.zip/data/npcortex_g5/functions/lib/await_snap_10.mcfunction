scoreboard players operation #m g5 = #tick g5
scoreboard players operation #m g5 %= #aw g5
execute if score #m g5 matches 0 run execute as @a[tag=g5_op,limit=1] run npcortex debug cplus m03 snapshot yui
execute if score #m g5 matches 0 run execute as @a[tag=g5_op,limit=1] run npcortex debug cplus m03 snapshot g5n02
execute if score #m g5 matches 0 run execute as @a[tag=g5_op,limit=1] run npcortex debug cplus m03 snapshot g5n03
execute if score #m g5 matches 0 run execute as @a[tag=g5_op,limit=1] run npcortex debug cplus m03 snapshot g5n04
execute if score #m g5 matches 0 run execute as @a[tag=g5_op,limit=1] run npcortex debug cplus m03 snapshot g5n05
execute if score #m g5 matches 0 run execute as @a[tag=g5_op,limit=1] run npcortex debug cplus m03 snapshot g5n06
execute if score #m g5 matches 0 run execute as @a[tag=g5_op,limit=1] run npcortex debug cplus m03 snapshot g5n07
execute if score #m g5 matches 0 run execute as @a[tag=g5_op,limit=1] run npcortex debug cplus m03 snapshot g5n08
execute if score #m g5 matches 0 run execute as @a[tag=g5_op,limit=1] run npcortex debug cplus m03 snapshot g5n09
execute if score #m g5 matches 0 run execute as @a[tag=g5_op,limit=1] run npcortex debug cplus m03 snapshot g5n10
